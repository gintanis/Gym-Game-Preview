﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DumbBells : MonoBehaviour
{
    public Rigidbody DB; 
    public KeyCode Lifting;
    public Vector3 DBPos;
    public bool Lifted;

    public float LiftTime;


   
    // Start is called before the first frame update
    void Start()
    {

       
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        DB.velocity = DBPos;

        if (Input.GetKey(Lifting) && Lifted == false )
        {
            transform.position += new Vector3(0, LiftTime, 0);
           // transform.Translate(0, .2f, 0);
           
        }


        if (transform.position.y >= 1.5f)
        {
             
                
            Lifted = true;
            DBPos.y = -Mathf.Abs(DBPos.y);
        }

        if (transform.position.y <= .39f)
        {
            Lifted = false; 
        }
        
        
    }


   


 
}
