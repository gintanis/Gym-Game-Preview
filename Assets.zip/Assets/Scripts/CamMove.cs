﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamMove : MonoBehaviour
{
    public float verticalAngle; 
   

  
    void Update()
    {
        float mouseY = Input.GetAxis("Mouse Y"); 
        
        
        transform.Rotate(-mouseY * 10f, 0f, 0f );

        
        verticalAngle -= mouseY * 10f; 
        verticalAngle = Mathf.Clamp( verticalAngle , -80f, 80f);
            
     
        transform.localEulerAngles =  new Vector3(verticalAngle, transform.localEulerAngles.y, 0f);
    }
}
