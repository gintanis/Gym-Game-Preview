﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public Rigidbody MyRB;
    
    [Header("Start DumbBells", order = 1)] public GameObject DbOne;
    public GameObject DbTwo;
    public bool startdb;


    [Header("Start Bench", order = 2)] public GameObject bench;
    public bool startbp;
    public GameObject barbell;

    [Header("Start Pull Ups", order = 3)] 
    public bool Grounded;
    public Vector3 RBPos; 
   

   
    void Start()
    {
        DbOne = GameObject.Find("DumbBell");
        DbTwo = GameObject.Find("DumbBellTwo");
        barbell = GameObject.Find("Barbell");

        
        
        DbOne.GetComponent<DumbBells>().enabled = false; 
        DbTwo.GetComponent<DumbBells>().enabled = false; 


    }

    // Update is called once per frame
    void Update()
    {
        MyRB.velocity = RBPos; 

        if (Input.GetKey(KeyCode.A))
        {
            transform.Rotate(0f, -1.5f, 0f);
        }

        if (Input.GetKey(KeyCode.D))
        {
            transform.Rotate(0f, 1.5f, 0f);
        }

        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(0, 0, .1f);
        }

        if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(0, 0, -.1f);
        }

        if (Input.GetKey(KeyCode.Space) && startdb)
        {

                        startdb = false; 
                        DbOne.GetComponent<DumbBells>().enabled = false; 
                        DbTwo.GetComponent<DumbBells>().enabled = false;
            barbell.GetComponent<Barbell>().enabled = false; 

        }


        if (Input.GetKey(KeyCode.Space) && startbp)
        {
            transform.position = bench.transform.position + new Vector3(3, 0, 0);
            transform.Rotate(90, 0, 0);
            startbp = false; 
            barbell.SendMessage("EndWorkout");
        }

      

        if (Input.GetKey(KeyCode.UpArrow) && Grounded)
        {
           transform.position += new Vector3(0, .5f, 0);
          
            
            
         
        }  
        
        if (transform.position.y >= 4.5f)
        {
            // transform.position += new Vector3(0, -.5f, 0);
            RBPos.y = -Mathf.Abs(RBPos.y);
            Grounded = false;
        }


        if (Input.GetKey(KeyCode.Space) && Grounded)
        {
            Grounded = false; 

        }



    }


    public void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.name == "DBMat")
        {
            DbOne.GetComponent<DumbBells>().enabled = true; 
            DbTwo.GetComponent<DumbBells>().enabled = true;
            startdb = true; 
        }

        if (collision.gameObject.name == "BPMat")
        {
            
            transform.position = bench.transform.position + new Vector3(0, 2, 0);
           
            transform.Rotate(-90, 180, 0);
            startbp = true;

            barbell.GetComponent<Barbell>().enabled = true; 
            barbell.SendMessage("StartWorkout");
            
        }

        if (collision.gameObject.name == "PUMat")
        {
        
          Grounded = true; 
        }

     
    }

   


  
}
